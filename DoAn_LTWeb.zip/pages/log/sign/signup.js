function open1(){
    window.location.href = "./signin.php";
}
function open2(){
    window.location.href = "./signup.php";
}
function open3(){
    window.location.href = "./signup.php";
}