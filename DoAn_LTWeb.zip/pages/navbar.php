<div style="background-color: #2E8B57;" class="container-fluid navbar-init">
    <nav class="navbar navbar-expand-sm navbar-light">
        <div class="container">
            <ul class="navbar-nav navbar-links">
                <li class="nav-item">
                    <a class="nav-link" href="index.php?quanly=index">Trang chủ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?quanly=gioithieu">Giới thiệu</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?quanly=lienhe">Liên hệ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?quanly=hoadon">Đơn hàng</a>
                </li>
            </ul>
            <!-- nut gom menu -->
            <div class="navbar-icons">
                <div class="navbar-icon"></div>
            </div>
        </div>
    </nav>
</div>