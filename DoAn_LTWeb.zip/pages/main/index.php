<head>
    <title>Trang chủ</title>
</head>
<?php
    include("category.php");
    include("carousel.php");
?>