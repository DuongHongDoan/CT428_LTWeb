<ul class="ad_navbar">
    <li>
        <a href="index.php?action=quanlydanhmucsanpham&query=them">Quản lý danh mục sản phẩm</a>
    </li>
    <li>
        <a href="index.php?action=quanlysanpham&query=them">Quản lý sản phẩm</a>
    </li>
    <li>
        <a href="index.php?action=quanlytaikhoan&query=them">Quản lý tài khoản</a>
    </li>
    <li>
        <a href="index.php?action=quanlydonhang&query=sua">Quản lý đơn hàng</a>
    </li>
</ul>